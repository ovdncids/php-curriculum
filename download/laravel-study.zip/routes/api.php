<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Laravel\Fortify\Http\Controllers\RegisteredUserController;
use App\Models\User;
use App\Http\Resources\UserResource;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return (new UserResource($request->user()))->response();
});

Route::middleware(['guest:'.config('fortify.guard')])
    ->post('/register', [RegisteredUserController::class, 'store']);

Route::post('/login', function (Request $request) {
    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
        'device_name' => 'required'
    ]);
    $user = User::where('email', $request->email)->first();
    if (!$user || !Hash::check($request->password, $user->password)) {
        throw ValidationException::withMessages([
            'email' => ['이메일 또는 비밀번호가 일치하지 않습니다.']
        ]);
    }
    return $user->createToken($request->device_name)->plainTextToken;
});

Route::middleware('auth:sanctum')
    ->get('/logout', function (Request $request) {
        // 해당 User가 로그인된 모든 device에 로그아웃
        $request->user()->tokens()->delete();
        // 해당 User의 현재 토큰만 로그아웃
        // $request->user()->currentAccessToken()->delete();
        return response()->json([
            'message' => '토큰만료 성공'
        ]);
    }
);

Route::prefix(env('APP_VERSION').'/')->group(function () {
    Route::apiResource('todo', \App\Http\Controllers\API\TodoController::class);
});
