<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Todo;
use App\Http\Resources\TodoResource;
use App\Http\Requests\TodoRequest;

class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return TodoResource::collection(Todo::orderBy('id', 'desc')->paginate(10));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TodoRequest $request)
    {
        $createTodo = Todo::create($request->all());
        return new TodoResource($createTodo);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (Todo::where('id', $id)->exists()) {
            return new TodoResource(Todo::find($id));
        } else {
            return response()->json([
                "message" => "Not found"
            ], \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (Todo::where('id', $id)->exists()) {
            $updateTodo = Todo::find($id);
            $updateTodo->update($request->all());
            return new TodoResource($updateTodo);
        } else {
            return response()->json([
                "message" => "Not found"
            ], \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (Todo::where('id', $id)->exists()) {
            $deleteTodo = Todo::find($id);
            $deleteTodo->delete();
            return response()->json([
                "message" => "Deleted"
            ]);
        } else {
            return response()->json([
                "message" => "Not found"
            ], \Symfony\Component\HttpFoundation\Response::HTTP_NOT_FOUND);
        }
    }
}
